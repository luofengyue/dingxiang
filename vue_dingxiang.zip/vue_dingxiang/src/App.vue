<template>
  <div id="app">
    
    <router-view/>
  </div>
</template>

<style lang="less">
//1.引入公告的初始化文件
//@import url("@/assets/css/reset.css");


</style>
