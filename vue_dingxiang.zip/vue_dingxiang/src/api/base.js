/**
 * 公告url
 * */ 

const base={
    host:'http://api.tianapi.com/',//天行数据  关于病毒
    convInfo: 'ncov/index?key=3acc329323474954f9fab4677f2dd77d'//病毒信息请求接口
}

export default base;